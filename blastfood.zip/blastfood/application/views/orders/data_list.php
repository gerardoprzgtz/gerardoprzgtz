 


<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        
                        
                        <!-- Button trigger modal -->
                        
                        <!--
<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
  Launch demo modal
</button>-->

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modal_container">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
                        
                        
                        <br>
                        <!--<h1 class="mt-4"><?php echo $title ?></h1>-->
                        <ol class="breadcrumb mb-4">
                            <!-- <?php
                            
                            $first_breadcrum=array_shift($breadcrum);
                            ?> -->
                                <li class="breadcrumb-item"><?php echo ucfirst( "Item" ); ?></li>
                                <li class="breadcrumb-item active">
                                    <small> <a href="<?php echo base_url();?>inventory/register">[ Add ]</a> </small>    
                                </li>
                        </ol>
                        
                        
                        <div class="card mb-4">
                            <!--<div class="card-header"><i class="fas fa-table mr-1"></i>DataTable Example</div>-->
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>                                                
                                                <th>Meal</th>
                                                <th>Qty</th>
                                                <th>Cost</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>Meal</th>
                                                <th>Qty</th>
                                                <th>Cost</th>
                                                <th>Actions</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php 
                                            $records=array(array(7,'Mariscos', 2,'23.00','actions'),
                                                           array(9,'Ensaladas',1,'23.00','actions'));
                                            if ($records)
                                            {
                                                foreach ($records as $record) 
                                                {
                                                    echo '<tr>';

                                                    $id=array_pop($record);

                                                    foreach ($record as $key => $val) 
                                                    {

                                                        
                                                        if (!(in_array($key, array('created_by','service_date','description'))))
                                                        {
                                                            echo '<td>';
                                                            echo ucfirst( $val );
                                                            echo '</td>';
                                                        }
                                                    }
                                                    ?>
                                                    <td>
                                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Details</button>
                                                        
                                                    </td>
                                                    <?php
                                                    echo '</tr>';

                                                }
                                                
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2020</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div> <!--   it closes layoutSidenav_content    -->