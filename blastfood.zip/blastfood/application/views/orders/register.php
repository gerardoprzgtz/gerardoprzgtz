<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Page Title - SB Admin</title>
        <link href="<?php echo base_url();?>startbootstrap-sb-admin-gh-pages/dist/css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-dark">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-4">
                                    <div class="card-header"><h4 class="text-center font-weight-light my-4">Order Register</h4></div>
                                    <div class="card-body">
                                       <?php echo form_open('orders/create','id="form_register"'); ?>
                                            <div class="form-group">
                                                <?php echo form_label('Category','category_lbl','class="small mb-1"'); ?>
                                                <?php 
                                                    echo form_dropdown('category',$category_options,$category,'id="category" class="form-control py-2"');
                                                    echo  form_error('category');
                                                ?>                                                
                                            </div>
                                        
                                            <div class="form-group">
                                                <?php echo form_label('Meal','meal_lbl','class="small mb-1"'); ?>
                                                <?php
                                                    $meal=$this->input->post('meal');
                                                    echo form_dropdown('meal',$meals_options,$meal,'id="meal" class="form-control py-2"');
                                                    echo  form_error('meal');
                                                ?>                                                
                                            </div>
                                        
                                            <div class="form-group">
                                                <?php echo form_label('Cost','cost','class="small mb-1"'); ?>
                                                <?php $cost_attribs=array('name'=>'cost', 'value'=> set_value('cost'), 'class'=>'form-control py-2','id'=>'cost','placeholder'=>'Type cost');
                                                      echo form_input($cost_attribs);
                                                      echo  form_error('cost');
                                                ?>
                                            </div>

                                            <div class="form-group">
                                                <?php echo form_label('Quantity','quantity','class="small mb-1"'); ?>
                                                <?php $quantity_attribs=array('name'=>'quantity', 'value'=> set_value('quantity'), 'class'=>'form-control py-2','id'=>'quantity','placeholder'=>'Type quantity');
                                                      echo form_input($quantity_attribs);
                                                      echo  form_error('quantity');
                                                ?>
                                            </div>
                                        
                                     

                                        <div class="form-group mt-4 mb-0">                                                
                                             <input type="submit" class="btn btn-primary btn-block" value="Accept" />                                               
                                             <a href="<?php echo base_url();?>dashboard" class="btn btn-dark btn-block">Cancel</a>
                                        </div>
                                       <?php echo form_close(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; BlastFood 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url();?>startbootstrap-sb-admin-gh-pages/dist/js/scripts.js"></script>
        <?php if ($load_jquerycode){ ?>
        <script>
        $(document).ready(function()
        {
            
            //$('#form_register').length;
            $('#category').on('change',function()
            {                           
                //var csrf_test_name_var = $("input[name=csrf_test_name1]").val();
                $("#cost").val("00.00");
                //,csrf_test_name1:csrf_test_name_var  este param tmb se envia en el post function
                $.post("<?php echo base_url().$controller;?>/get_meals_ajax",{ id_category:this.value} ,function( data,status )
                {
                    if (Object.keys(data).length > 0)
                    {
                        $('#form_register select[name="meal"]').empty();
                        $('#form_register select[name="meal"]').append('<option value="">--Choose--</option>');
                        $.each(data,function(k,array)
                        {
                            $('#form_register select[name="meal"]').append('<option value="'+k+'">'+ array + '</option>');
                        });
                    }
                    else
                    {
                        $('#form_register select[name="meal"]').empty();
                        $('#form_register select[name="meal"]').append('<option value="">--Choose--</option>');
                    }
                },
                'json');  //close $post
            });
          
          
          
          $('#meal').on('change',function()
            {                           
                //var csrf_test_name_var = $("input[name=csrf_test_name1]").val();
                //alert(this.value);
                //,csrf_test_name1:csrf_test_name_var  este param tmb se envia en el post function
                $.post("<?php echo base_url().$controller;?>/get_price_ajax",{ id_meal:this.value} ,function( data,status )
                {
                    
                        $("#cost").val(data);
                    
                   
                },
                'json');  //close $post
            });
        });
            </script>
        <?php  }?>
        
        
        
    </body>
</html>
