<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <br>
                        <ol class="breadcrumb mb-4">
                            <li class="breadcrumb-item">My profile</li>
                        </ol>
                        
                        <?php if ($mje= ($this->session->flashdata('account_created'))) { ?>
                        <div class = "alert alert-success animated"><?php echo $mje; ?></div>
                        <?php } ?>
                        
                        
                
                        <div class="row">
                            <div class="col-xl-4">
                                

                                <div class="card mb-4">
                                    
                                    <div class="card-body">
                                        
                                        <img class="d-block w-100 rounded" src="<?php echo base_url();?>images/userboy.jpg" alt="Second slide">
                                    </div>
                                </div>
                                    
                            </div>  
                            
                            <div class="col-xl-8">
                                <div class="card mb-4">                                   
                                    <div class="card-body">                                                                                                                        
                                        <div class="accordion" id="accordionExample">
  <div class="card">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          Personal data
        </button>
      </h2>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
          Espacio disponible para mostar los datos de determinado alumno:
            <ul class="list-group list-group-flush">
                 <li class="list-group-item">Nombre</li>
                <li class="list-group-item">Especialidad</li>
                <li class="list-group-item">email</li>
            </ul>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingTwo">
      <h2 class="mb-0">
        <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          Permissions
        </button>
      </h2>
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
      <div class="card-body">
          Espacio disponible para mostar los permisos correspondientes al perfil.Ej.
          <ul class="list-group list-group-flush">
                <li class="list-group-item">Crear</li>
                <li class="list-group-item">Editar</li>
                <li class="list-group-item">Mostar</li>
            </ul>
      </div>
    </div>
  </div>
  <div class="card">
    <div class="card-header" id="headingThree">
      <h2 class="mb-0">
        <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          My last meal
        </button>
      </h2>
    </div>
    <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
      <div class="card-body">                            
          Espacio disponible para mostar el ultimo platillo.
      </div>
    </div>
  </div>
</div>
                                    </div>
                                </div>   <!--  closes card mb-4  -->
                            </div>
                        </div>
                        
                        
                        
                        
          
                        
                        
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; BlastFood 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div> <!--   it closes layoutSidenav_content    -->