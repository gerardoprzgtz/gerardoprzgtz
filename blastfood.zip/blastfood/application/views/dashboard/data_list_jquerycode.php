<script>


$(document).ready(function(){

    $("a[name^='details']").click(function(e)
    {
        var node = this.name;
        var node_arr = node.split("_");
        var node_qty = node_arr.length;
        var id_target= node_arr[node_qty-1];
        var records_arr=<?php echo json_encode($records); ?>;
              //alert("id_tagte" + id_target);
        $.each(records_arr, function( index, value ) 
        {
            var id=records_arr[index]['id'];
            if ( id == id_target )
            {
                $("#modal_container").empty();
                //$("#modal_container").html(records_arr[index]['service']);
                $("#modal_container").html('servicio: ' +records_arr[index]['service'] +'\n\
                                            <ul class="list-group list-group-flush">\n\
                                            <li class="list-group-item"><b>Costo:</b> '+records_arr[index]['cost']+' </li>\n\
                                            <li class="list-group-item"><b>Fecha:</b> '+records_arr[index]['service_date']+'</li>\n\
                                            <li class="list-group-item"><b>Autor:</b> '+records_arr[index]['created_by']+'</li>\n\
                                            <li class="list-group-item"><b>Description:</b> '+records_arr[index]['description']+'</li></ul>');
                $('#exampleModal').modal('show');
                return;
            }
        });
        
                //alert('id ' + id);
                        
            
            
    
        return e.preventDefault();
  
        
    });


  // jQuery methods go here...

 //$("button").click(function(){
    //$("p").hide(1000);
    
    //$(".animated").fadeOut(5000);
    
    // $("#panel").slideDown("slow");
    
    //$(".animated").slideUp(3000).slideDown(1000).fadeOut(2000);
    
    //alert("ok");
    //$(".img_animated").addClass("fadeIn");
   
    
 // });
});

    </script>