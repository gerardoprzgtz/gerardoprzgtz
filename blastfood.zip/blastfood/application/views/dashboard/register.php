<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Page Title - SB Admin</title>
        <link href="<?php echo base_url();?>startbootstrap-sb-admin-gh-pages/dist/css/styles.css" rel="stylesheet" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/js/all.min.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-dark">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-4">
                                    <div class="card-header"><h4 class="text-center font-weight-light my-4">Order Register</h4></div>
                                    <div class="card-body">
                                       <?php echo form_open('dashboard/create','id="form_register"'); ?>
                                            <div class="form-group">
                                                <?php echo form_label('Category','category_lbl','class="small mb-1"'); ?>
                                                <?php 
                                                    
                                                    $category=$this->input->post('category');
                                                    echo form_dropdown('category',$category_options,$category,'id="category" class="form-control py-2"');
                                                    echo  form_error('category');
                                                ?>                                                
                                            </div>
                                        
                                            <div class="form-group">
                                                <?php echo form_label('Meal','user_lbl','class="small mb-1"'); ?>
                                                <?php
                                                    $user=$this->input->post('user');
                                                    echo form_dropdown('user',$users_options,$user,'id="user" class="form-control py-2"');
                                                    echo  form_error('user');
                                                ?>                                                
                                            </div>
                                        
                                            <div class="form-group">
                                                <?php echo form_label('Cost','category','class="small mb-1"'); ?>
                                                <?php 
                                                    $category=$this->input->post('category');
                                                    echo form_dropdown( 'category',array(),$category,'id="category" class="form-control py-2"');
                                                    echo  form_error('category');
                                                ?>                                                
                                            </div>
                                        
                                            <div class="form-group">
                                                <?php echo form_label('Quantity','service','class="small mb-1"'); ?>
                                                <?php 
                                                    $service=$this->input->post('service');
                                                    echo form_dropdown( 'service',$service_ops,$service,'id="service" class="form-control py-2"');
                                                    echo  form_error('service');
                                                ?>                                                
                                            </div>
                                        
                                            <div class="form-group">
                                                <?php echo form_label('Cost','cost','class="small mb-1"'); ?>
                                                <?php $cost_attribs=array('name'=>'cost', 'value'=> set_value('cost'), 'class'=>'form-control py-2','id'=>'cost','placeholder'=>'Type cost');
                                                      echo form_input($cost_attribs);
                                                      echo  form_error('cost');
                                                ?>
                                            </div>
                                        
                                            <div class="form-group">
                                                <?php echo form_label('Description','description','class="small mb-1"'); ?>
                                                <?php $description_attribs=array('name'=>'description', 'value'=> set_value('description'), 'class'=>'form-control py-2','id'=>'description','placeholder'=>'Type description');
                                                      echo form_input($description_attribs);
                                                      echo  form_error('description');
                                                      
//                                                      if ($incorrect_passord)
//                                                      {
//                                                          
//                                                          echo '<div class="text-danger">Incorrect description</div>';
//                                                      }
                                                ?>
                                            </div>
                                        <div class="form-group mt-4 mb-0">                                                
                                             <input type="submit" class="btn btn-primary btn-block" value="Accept" />                                               
                                             <a href="<?php echo base_url()?>inventory/data_list" class="btn btn-dark btn-block">Cancel</a>
                                        </div>
                                       <?php echo form_close(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="layoutAuthentication_footer">
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2020</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
        <script src="https://code.jquery.com/jquery-3.4.1.min.js" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="<?php echo base_url();?>startbootstrap-sb-admin-gh-pages/dist/js/scripts.js"></script>
        <?php if ($load_jquerycode){ ?>
        <script>
        $(document).ready(function()
        {
            
            //$('#form_register').length;
            $('#category').on('change',function()
            {                           
                //var csrf_test_name_var = $("input[name=csrf_test_name1]").val();
                alert(this.val);
                //,csrf_test_name1:csrf_test_name_var  este param tmb se envia en el post function
                $.post("<?php echo base_url().$controller;?>/get_users_by_customer_ajax",{ id_customer:this.value} ,function( data,status )
                {
                    if (Object.keys(data).length > 0)
                    {
                        $('#form_register select[name="user"]').empty();
                        $('#form_register select[name="user"]').append('<option value="">--Choose--</option>');
                        $.each(data,function(k,array)
                        {
                            $('#form_register select[name="user"]').append('<option value="'+k+'">'+ array + '</option>');
                        });
                    }
                    else
                    {
                        $('#form_register select[name="user"]').empty();
                        $('#form_register select[name="user"]').append('<option value="">--Choose--</option>');
                    }
                },
                'json');  //close $post
            });
          
          
          
          $('#category').on('change',function()
            {                           
                //var csrf_test_name_var = $("input[name=csrf_test_name1]").val();
                
                //,csrf_test_name1:csrf_test_name_var  este param tmb se envia en el post function
                $.post("<?php echo base_url().$controller;?>/get_services_ajax",{ id_category:this.value} ,function( data,status )
                {
                    if (Object.keys(data).length > 0)
                    {
                        $('#form_register select[name="service"]').empty();
                        $('#form_register select[name="service"]').append('<option value="">--Choose--</option>');
                        $.each(data,function(k,array)
                        {
                            $('#form_register select[name="service"]').append('<option value="'+k+'">'+ array + '</option>');
                        });
                    }
                    else
                    {
                        $('#form_register select[name="service"]').empty();
                        $('#form_register select[name="service"]').append('<option value="">--Choose--</option>');
                    }
                },
                'json');  //close $post
            });
        });
            </script>
        <?php  }?>
        
        
        
    </body>
</html>
