<div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        
                        
                        <!-- Button trigger modal -->
                        
   

<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Detail pending</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body" id="modal_container">
        click close
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>
                        
                        
                        <br>
                        <ol class="breadcrumb mb-4">
                                <li class="breadcrumb-item"><?php echo ucfirst( "Orders" ); ?></li>
                                <li class="breadcrumb-item active">
                                    <small> <a href="<?php echo base_url();?>orders/register">[ Add ]</a> </small>    
                                </li>
                        </ol>
                        
                        
                        <div class="card mb-4">
                            <div class="card-body">
                            <?php echo form_open('dashboard','id="form_register"'); ?>
                            <div class="form-row">
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label class="small mb-1" for="inputMonth">Month</label>
                                                        <?php 
                                                            echo form_dropdown('month',array('Todos' ,'Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'),$month,'id="month" class="form-control py-2"');
                                                            echo  form_error('month');
                                                        ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group">
                                                        <label class="small mb-1" for="inputCategory">Category</label>
                                                        <?php 
                                                            echo form_dropdown('category',$category_options,$category,'id="category" class="form-control py-2"');
                                                            echo  form_error('category');
                                                        ?>
                                                    </div>
                                                </div>
                                                <div class="col-md-4">
                                                    <div class="form-group"><label class="small mb-1" for="inputAccept"></label>
                                                    <input type="submit" class="btn btn-primary btn-block" value="Accept" />
                                                </div>
                                                </div>
                                            </div>


                                            
                            <?php echo form_close(); ?>
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>                                                
                                                <th>Meal</th>
                                                <th>Qty</th>
                                                <th>Cost</th>
                                                <th>Got paid</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>Meal</th>
                                                <th>Qty</th>
                                                <th>Cost</th>
                                                <th>Got paid</th>
                                                <th>Actions</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php 
                                            if ($records)
                                            {
                                                foreach ($records as $record) 
                                                {
                                                    echo '<tr>';
                                                    $id=array_pop($record);
                                                    $id_user=array_pop($record);
                                                    $created_on=array_pop($record);
                                                    foreach ($record as $key => $val) 
                                                    {
                                                            echo '<td>';
                                                            echo ($key=='id_meal') ? $meals[$val] : ucfirst( $val );
                                                            echo '</td>';
                                                        
                                                    }
                                                    ?>

                                                    <td>
                                                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Details</button>
                                                        
                                                    </td>
                                                    <?php
                                                    echo '</tr>';

                                                }
                                                
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; BlastFood 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div> <!--   it closes layoutSidenav_content    -->