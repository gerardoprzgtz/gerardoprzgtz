 <div id="layoutSidenav_content">
                <main>
                    <div class="container-fluid">
                        <ol class="breadcrumb mb-2 m-2">
                                <li class="breadcrumb-item"><a href="<?php echo base_url();?>welcome">Meals</a></li>
                                <li class="breadcrumb-item active">
                                    <small> <?php echo ucfirst( $category ); ?> </small>    
                                </li>
                        </ol>
                        <div class="row">
                            <div class="col-xl-6 col-md-6">
                                <div class="card bg-warning text-white mb-4">
                                    <div class="card-body">Promociones</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xl-6 col-md-6">
                                <div class="card bg-success text-white mb-4">
                                    <div class="card-body">Mas vendidos</div>
                                    <div class="card-footer d-flex align-items-center justify-content-between">
                                        <a class="small text-white stretched-link" href="#">View Details</a>
                                        <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="row">
                                <?php 
                                
                                foreach($meals_tree as $meal)
                                {
                                    $id=$meal[0];
                                    $name=$meal[1];
                                    $has_children=$meal[2];
                                    $parent=$meal[3];
                                    $image_path=$meal[5];
                                    $description=$meal[6];    
                                        
                                    ?>
                                            <div class="col-xl-6">
                                                <div class="card mb-4">
                                                    <div class="card-header"><i class="fas fa-chart-bar mr-1"></i><?php echo $name; ?></div>

                                                  <?php  if ($has_children) { ?>
                                                    <div class="card-body"><a href='<?php echo base_url()."welcome/index/".$id;?>'><img class="d-block w-100" src='<?php echo base_url(). $image_path ;?>' alt="Third slide"></a></div>
                                                    <?php  }else { ?>
                                                    <div class="card-body"><img class="d-block w-100" src='<?php echo base_url(). $image_path ;?>' alt="Third slide"></div>
                                                    <?php  } ?>
                                                    
                                                </div>
                                            </div>
                                <?php   
                                                                         
                                }                            
                                ?>
                        </div>


                        
                    </div>
                </main>
                <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; BlastFood 2021</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer>
            </div> <!--   it closes layoutSidenav_content    -->