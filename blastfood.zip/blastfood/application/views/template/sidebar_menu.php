 <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">                        
                            <?php if  ( ( $this->session->userdata('logged_in')) && ( in_array('core',$available_controllers))) { ?>
                            
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="#"><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>Permissions</a>
                            <a class="nav-link" href="#"><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>Backup</a>
                            <a class="nav-link" href="#"><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>Uploads</a>
                            <?php } ?>
                            
                            <?php if  ( ( $this->session->userdata('logged_in')) && ( in_array('dashboard',$available_controllers))) { ?>
                            <div class="sb-sidenav-menu-heading">Settings</div>
                            <a class="nav-link" href="<?php echo base_url();?>dashboard"><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>Orders</a>
                            <a class="nav-link" href="<?php echo base_url();?>profiles"><div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>Profile</a>
                            <?php } ?>
                            
                            
                            <div class="sb-sidenav-menu-heading">More</div>
                            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseLayouts" aria-expanded="false" aria-controls="collapseLayouts"><div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>Postres<div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div></a>
                            <div class="collapse" id="collapseLayouts" aria-labelledby="headingOne" data-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link" href="#">Helados</a>
                                    <a class="nav-link" href="#">Pays</a>
                                    <a class="nav-link" href="#">Pasteles</a>
                                </nav>
                            </div>
                            
                            
                            
                            
                            
                        </div>
                    </div>
                    <div class="sb-sidenav-footer">                
                        Contacto
                        <a href="#"><img class="img-fluid rounded" src="<?php echo base_url();?>images/whatsapp-icon1.png"></a>
                        <a href="#"><img class="img-fluid rounded" src="<?php echo base_url();?>images/email1.jpg"></a>
                    </div>
                    
                </nav>
            </div>