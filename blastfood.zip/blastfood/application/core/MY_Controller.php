<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class MY_Controller extends CI_Controller {

 public $available_controllers=array();
 public $available_methods=array();
 public $available_methods_ajax=array();
 private static $breadcrum=array();
 
    public function get_menu_id($model_name)
    {    
        $menus_tree=$this->config->item('menus_tree');
        $counter=1;
        $id_menu=0;
        $times_of_menu_appears=0;
        $total_of_menus= count($menus_tree);
            

        foreach ($menus_tree as $data_array)
        {            
            $index=$data_array[0];
            if ($index==$counter)
            {
                $menu_name      = $data_array[1];
                $children_qty   = $data_array[2];
                $parent         = $data_array[3];

                if ( strtolower( trim($model_name) ) == strtolower( trim($menu_name) ) )
                {
                    $id_menu=$index;
                    $times_of_menu_appears++;
                }
            }
            else
            {
                break;
            }
            $counter++;
        }

        
        return  ( ($times_of_menu_appears==1) && ($id_menu) && ($index == $total_of_menus) ) ? $id_menu : 0;
    }
    
    public function verify_permission($autoload_model=FALSE)
    {
        $id_profile = ($this->session->has_userdata("id_profile")) ? $this->session->userdata("id_profile") : 0;
        $menus_tree   = $this->config->item('menus_tree');
        $profiles   = $this->config->item('profiles');
        $model_name = strtolower( $this->uri->segment(1));
        $method     = strtolower( $this->uri->segment(2,'index'));
        //--------------------------------------------------------
        
        
        if ($id_profile)
        {
            $profile_data=$profiles[$id_profile];
            $profile_name = $profile_data[0];
            $id_method_stored = $profile_data[1];
            $id_menu_str = $profile_data[2];
            $id_menu_end = $profile_data[3];
            
            $id_menu=$this->get_menu_id($model_name);

                if ( $id_menu )
                {                    
                
                    $methods     = $this->config->item('methods');
                    if (!(empty($this->available_methods_ajax)))
                    {
                        foreach ($this->available_methods_ajax as $method_ajax) 
                        {
                            array_push($methods,$method_ajax);
                        }
                    }
                    $methods_qty = count( $methods );


                   
                                
                    //Un perfil solo tiene disponible ciertos menus (controllers)
                    if  (($id_menu>=$id_menu_str) && ($id_menu<=$id_menu_end))
                    {
                        $id_method = array_search($method, $methods);

                        if ($id_method)
                        {
                            if (($id_method>=$id_method_stored) && ($id_method<=$methods_qty))
                            {
                             
                                
                                if ($autoload_model)
                                    $this->load->model(ucfirst($model_name).'_model','model_self');                        

                                $preserve_keys=TRUE;
                                $length=NULL;
                                $this->available_methods=array_slice($methods,abs(($id_method_stored-1)),$length,$preserve_keys);
                                                                
                                
                                $menus_availables=[];
                        
                                foreach ($menus_tree as  $v) 
                                {
                                    $menu_id=$v[0];
                                    $menu_name=$v[1];
                                    $menu_qty=$v[2];
                                    $menu_parent=$v[3];
                                    
                                    if (($menu_id >= $id_menu_str) && ($menu_id <= $id_menu_end))
                                        $menus_availables[$menu_id] = $menu_name;
                                }
                                
                                
                                $this->available_controllers=$menus_availables;
                                $this->profile_name=$profile_name;
                                return  ( $this->available_methods && $this->available_controllers );
                            }
                        }
                    } 
                }
        }
        return FALSE;
    }    
    
    public function print_r($arr) {
        echo '<pre>';
        print_r($arr);
        echo '</pre>';
    }
}