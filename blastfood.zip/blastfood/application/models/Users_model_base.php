<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Users_model extends CI_Model {

    
    function check_credentials($email,$pass) {
        $result=$this->db->get_where('users',array('email'=>$email,'password'=>md5($pass)));
        
        if ($result)
        {
            return $result->row_array();
        }
        else
        {
            return false;
        }
        
    }
    
    //
    public function create($data) 
    {
        $this->db->insert('users', $data);
        // Produces: INSERT INTO mytable (title, name, date) VALUES ('My title', 'My name', 'My date')
    }
    
}