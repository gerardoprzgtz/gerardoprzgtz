<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

class Authentication_model extends CI_Model {
        
    function check_credentials($email,$pass) {
        
        $result=$this->db->get_where('users',array('email'=>$email,'password'=>md5($pass)));
        $result_qty = count( $result->result_array());
        
        
        if ( $result_qty == 1)
        {
            return $result->row_array();
        }
        else
        {
            return array();
        }
        
    }
    
    
    function email_exists($email, $return_password = false) {
                                
        $query=$this->db->get_where('users',array('email'=>$email));
        $result =  $query->result_array();
        
        if ( count( $result ) ==1)
        {
            if ($return_password )
            {
                echo $result[0]['password'];
            }
            else
            {
                return TRUE;
            }
        }
        else
        {
            return FALSE;
        }
    }
    
}