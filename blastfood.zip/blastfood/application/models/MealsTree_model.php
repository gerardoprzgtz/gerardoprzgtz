<?php

class MealsTree_model extends MY_Model
{
    protected $table_name   = ""; //methods_by_profile
    protected $key          = 'id';
    protected $soft_deletes = FALSE;
    protected $date_format  = 'datetime';
    protected $log_user     = FALSE;

    protected $set_created  = TRUE;
    protected $created_field    = 'created_on';
    protected $created_by_field = 'created_by';

    protected $set_modified     = FALSE;
    protected $modified_field   = 'modified_on';
    protected $modified_by_field = 'modified_by';

    protected $deleted_field    = 'deleted';
    protected $deleted_by_field = 'deleted_by';

    // Observers
    protected $before_insert    = array();
    protected $after_insert     = array();
    protected $before_update    = array();
    protected $after_update     = array();
    protected $before_find      = array();
    protected $after_find       = array();
    protected $before_delete    = array();
    protected $after_delete     = array();

    protected $return_insert_id = true;
    protected $return_type      = 'object';
    protected $protected_attributes = array();
    protected $field_info           = array();

    protected $validation_rules         = array();
    protected $insert_validation_rules  = array();
    protected $skip_validation          = false;
    protected $empty_validation_rules   = array();
    
    
    //id es el key del methods_by_profile ('admin', 'editor', 'guest')
    //y el segundo arg. significa si se requiere regresar si es ó no by-herency
    
    public function __construct()
    {
                
        //protected $table_name   = 'worked_hours_2016'; //methods_by_profile
        parent::__construct();
        
        //$current_year=abs(strtolower (($this->config->item('time_reference')) == 'gmt' ? gmdate('Y', time()) : date('Y', time())));
        
        //if ($current_year!=end($this->years))
            //exit ("years property need to be updated  by admin<br>Ref: ".__METHOD__);
        
        //$this->table_name='worked_hours_'.$current_year;
    }


    // it returns super parents
    
    public function get_children($field_value=0,$field_position=3,$return_entire_row=false,$include_parent_name=false)
    {
        //    0      1       2        3      4          5           6
        //    id    name    qty     parent  key     image_path  description
        $menus_tree=$this->config->item('meals_tree');    
        $result=[];   
        foreach ($menus_tree as $data_array)
        {        
            $index=$data_array[0];
            $name=$data_array[1];
            $parent=$data_array[$field_position];
            $meal_key=$data_array[4];
            if ($parent==$field_value)
            {    
                if ($return_entire_row)
                {
                    $result[]=$data_array;// $name.'-'.$meal_key;
                }
                else
                {
                    $result[$index]= $name;
                }
                
            }
        }


        if ($include_parent_name )
        {
            $result[]=$menus_tree[$field_value-1][1];
        }
        return $result;
        
    }

    public function get_menu_id($model_name)
    {    
        $menus_tree=$this->config->item('menus_tree');
        $counter=1;
        $id_menu=0;
        $times_of_menu_appears=0;
        $total_of_menus= count($menus_tree);
                
        foreach ($menus_tree as $data_array)
        {            
            $index=$data_array[0];
            if ($index==$counter)
            {
                $menu_name      = $data_array[1];
                $children_qty   = $data_array[2];
                $parent         = $data_array[3];

                if ( strtolower( trim($model_name) ) == strtolower( trim($menu_name) ) )
                {
                    $id_menu=$index;
                    $times_of_menu_appears++;
                }
            }
            else
            {
                break;
            }
            $counter++;
        }
                
        
        return  ( ($times_of_menu_appears==1) && ($id_menu) && ($index == $total_of_menus) ) ? $id_menu : 0;
    }


    public function breadcrum($n){                                        
        if($n<=0)
        {
            ksort( self::$breadcrum);
            return    self::$breadcrum;
        }
        else                        
            
    //        $result= $this->model_self->select("id,parent,name")
    //        ->as_array()
    //        ->find_by('id',$n);
        
            
            
        
             $result  = $this->config->item('menus_tree')[$n-1];
        
    //                 echo '<pre>';
    //                 print_r($result);
    //                 self::$breadcrum[$n]=$result[0];                 
    //                 echo '</pre>';
    //                exit(__METHOD__);
        
        
    //    Array
    //(
    //    [0] => 6
    //    [1] => inventory
    //    [2] => 0
    //    [3] => 5
    //)
                
            //primera iteracion de la recursividad
            if (empty (self::$breadcrum))
            {
                // no hacemos nada
            } 
            else
            {
                //verificamos que $n que se envió de la 1er iteracion sea igual 
                
                
    //            if   ( (($n-1)!=$result['parent'])  && ($result['parent']<>0 ))
    //            {                                                     
    //                exit("Error en la db, favor de checar el orden de hijo hasta el papá");
    //            }
                
            }         
               //self::$breadcrum[$n]=$result[0];                 
                                     
            self::$breadcrum[$result[0]]=$result[1];
            return $this->breadcrum($result[3]);        
        }
 
        
        

}

