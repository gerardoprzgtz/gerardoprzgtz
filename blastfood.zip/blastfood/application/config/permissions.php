<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['methods']=array(   
                            1=>'write',
                            2=>'delete',
                            3=>'uploads',
                            4=>'do_upload',
                            5=>'edit', 
                            6=>'update', 
                            7=>'register',
                            8=>'create',                            
                            9=>'data_list',
                            10=>'custom',
                            11=>'details',
                            12=>'index'
                        );



//                         id         name   id_meth  id_menu_str   id_menu_end                 crypted  
$config['profiles']=array( 1 =>array('admin',   1,      1,              11,          'ff509c42d846c1c5a68c3bc264dbcdd1'),// '3aeb330f47e08d8a77df2a4768e95ea2'),
                           2 =>array('auditor', 3,      1,              11,          'ff2619c89a1f7021cfda9d366691c549'),//  '7a293fcfec23742ea9bbc3441b05606d'),
                           3 =>array('guest',   9,      5,              11,          '7d0ac73c1e82594435f50e962101d0d3')); // 'd0ddfdad8239d7f8d06efc1928e70a75'));




  
$config['meals_tree']=array(  
        //    id      name             qty,   parent      key       image_path   description
	array('1', 'Ensaldas',          1,      0,      'eslda',        'images/ensaladas.jpg',             ''),
        array('2', 'Caprese',           0,      1,      'capre',        'images/caprese.jpg',             '59.00; caprese decr'),
        array('3', 'Mariscos',          3,      0,      'mrsco',        'images/mariscos.jpg',             ''),
        array('4', 'Filete',            0,      3,      'filte',        'images/filete.jpg',             '95.00; filete descr;kw'),
        array('5', 'Ceviche',           0,      3,      'cvche',        'images/ceviche.jpg',             '70.00; ceviche descr'),
        array('6', 'camaron',           0,      3,      'camrn',        'images/camaron.jpg',             '49.90; camaron desc'),
        array('7', 'Lovely',            2,      0,      'lovly',        'images/lovely.jpg',             ''),
        array('8', 'Hamburguesa',       0,      7,      'hambu',        'images/burguer1.jpg','65.00; hamb desc'),
        array('9', 'Hotdog',            0,      7,      'hotdg',        'images/hotdog.jpg','30.00; hotdog descr'));

//Under this context menus refers to controlles
$config['menus_tree']=array(
    // id            name               qty,   parent
        array('1', 'core',               3,      0), // for auditor
	array('2', 'permissions',        0,      1),
        array('3', 'backups',            0,      1),
        array('4', 'uploads',            0,      1),
    
        array('5', 'dashboard',          2,      0), // for guest   
        array('6', 'profiles',           0,      5), //
        array('7', 'orders',             0,      5), //   

        array('8', 'home',              3,      0),
        array('9', 'services',          0,      8),
        array('10', 'packages',         0,      8),
        array('11', 'welcome',          0,      8)
);

    