<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public $available_methods = array();
    public $available_controllers=array();
    
        public function __construct() 
        {
            parent::__construct();
            $this->load->helper('form');              
            $this->load->library('form_validation');
            $this->load->model('Authentication_model','Auth');
            $this->load->model('Users_model');
            $this->load->model('Profiles_model');
        }
        
        
	public function index()
	{
        $id_parent=$this->uri->segment(3,0);
        
        if ($id_parent)
        {
            $data['meals_tree']=$this->MealsTree_model->get_children($id_parent,3,true,true);
            $data['category']= array_pop($data['meals_tree']);
        }
        else
        {
            $data['meals_tree']=$this->MealsTree_model->get_children($id_parent,3,true);
            $data['category']= "Todas";

        }            
            
        $data['available_controllers'] =$this->available_controllers; 
        $this->load->view('template/top_menu');
        $this->load->view('template/sidebar_menu',$data);
        $this->load->view('template/content_menu_base',$data);            
        $this->load->view('template/pre_bottom_menu');
        $this->load->view('template/bottom_menu');
	}
         
       
    public function login($incorrect_pass=false)
	{              
        $data['incorrect_passord']=$incorrect_pass;
        $this->load->view('welcome/login',$data);
	}
        
    public function register()
	{            
            $this->load->view('welcome/register');
	}
                
    public function validate_account()
	{    
        $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
        $this->form_validation->set_rules('first_name', 'First name', 'required');
        $this->form_validation->set_rules('last_name', 'Last name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required',
                        array('required' => 'You must provide a %s.')
                );
            
        $this->form_validation->set_rules('re_password', 'Password Confirmation', 'required|matches[password]');
            
        if ($this->form_validation->run() == FALSE)
        {
            $this->register();                
        }
        else
        {
            $first_name  = $this->input->post('first_name');
            $last_name   = $this->input->post('last_name'); 
            $email       = $this->input->post('email');
            $password    = $this->input->post('password');                
            $account_data=array('id_profile'  => 3, 
                        'id_position' => 1, 
                        'first_name' => $first_name,
                        'last_name' => $last_name,
                        'email' => $email,
                        'password' => md5( $password ),
                );
            
            $this->Users_model->insert($account_data);
            $this->session->set_flashdata('account_created', 'Account created!!!');
            redirect('welcome');
        }
    }
        
        
    public function email_check($str)
    {
        $result=$this->Auth->email_exists($str);
            
        if ($result )
        {
            return TRUE;
        }
        else
        {
            $this->form_validation->set_message('email_check', 'The {field} is unknown');
            return FALSE;
        }
    }
        
    public function validate() //it validates login
	{
        $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email|callback_email_check');
        $this->form_validation->set_rules('password', 'Password', 'required');
        if ($this->form_validation->run() == FALSE)
        {
            $this->login();                
        }
        else
        {
            $email    = $this->input->post('email');
            $password = $this->input->post('password');
            $query=$this->Auth->check_credentials($email,$password);
            if ( empty($query))
            {
                $this->login(TRUE);
            }
            else
            {
                $profiles   = $this->config->item('profiles');
                $id_profile=$query['id_profile'];
                $sess_data = array(
                            'id_user' => $query['id'],
                            'id_profile' => $id_profile,
                            'id_position' => $query['id_position'],
                            'email'     =>  $query['email'],
                            'profile'=> ($id_profile)? $profiles[$id_profile][0] : '',
                            'logged_in' => TRUE
                            );
                $this->session->set_userdata($sess_data);
                redirect('dashboard');
            }
        }
    }
        
    public function logout() 
    {
        $newdata = array( 
                'id_user',
                'id_profile',
                'id_position',
                'profile',
                'email' ,
                'logged_in'
                );
                   
        $this->session->unset_userdata($newdata);
        $this->session->sess_destroy();
        redirect('welcome');
    }        
}
