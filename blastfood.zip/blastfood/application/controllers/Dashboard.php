<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends MY_Controller {

    
        public function __construct() 
        {
            parent::__construct();
            $this->load->helper('form');              
            $this->load->library('form_validation');
            $this->load->model('Inventory_model','model_self');
            $method= strtolower($this->uri->segment(2,'index'));

            if (  $method!='logout' && $method!='login' && $method!='validate' && $method!='register' && $method !='validate_account')
            {
                
                if ($this->session->userdata('logged_in'))
                {

                    $access_ok = $this->verify_permission();
                    if (! $access_ok )
                    {
                        show_error('<a href="' . base_url() . 'welcome">Get Login...!!!</a>',500,"Sorry you have not enough permission..!");
                    }
                }
            }
             
        }
    
    public function index()
	{
        $this->load->model('Orders_model');
        $this->load->model('MealsTree_model');
        $data['month']=$this->input->post('month');
        $data['category']=$this->input->post('category');
        $data['category_options']=$this->MealsTree_model->get_children();

        
        if (!$data['category'])
            $data['category']= array_keys($data['category_options'])[0];

        if (!$data['month'])
            $data['month']=6;

        $data['meals']=$this->MealsTree_model->get_children($data['category']);

        $data['category_options'][""]="Todas";
        ksort($data['category_options']);
        $data['records']= $this->Orders_model->select("id_meal,quantity,cost,got_paid,created_on,id_user,id")            
                ->where(array('id_user'=>$this->session->userdata("id_user"),'MONTH(created_on)'=>$data['month']))
                ->where_in('id_meal',array_keys($data['meals']))           
                ->order_by(array("orders.created_on"=>'desc'))
                ->as_array()
                ->find_all();

        $data['available_controllers'] =$this->available_controllers; 
        $this->load->view('template/top_menu');
        $this->load->view('template/sidebar_menu',$data);
        $this->load->view('dashboard/data_list',$data);            
        $this->load->view('template/pre_bottom_menu');
        $this->load->view('template/bottom_menu');
	}        
}
