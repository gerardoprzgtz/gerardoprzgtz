<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Orders extends MY_Controller {

    
    public $available_methods_ajax=array('get_users_by_customer_ajax','get_services_ajax');
    
        public function __construct() 
        {
            parent::__construct();
            $this->load->helper('form');              
            $this->load->library('form_validation');
            $this->load->model('Orders_model','model_self');            
            $method= strtolower($this->uri->segment(2,'index'));
             
        }
        
        
	public function index()
	{            
        $this->load->view('template/top_menu');
        $this->load->view('template/sidebar_menu');
        $this->load->view('template/content_menu',$data);
        $this->load->view('template/bottom_menu');
	}
        
        
        
        
        
        public function get_meals_ajax() 
        {        
        //if ($this->input->is_ajax_request())
        //{
            
            $id_category=$this->input->post('id_category');
            $result=[];
            if ($id_category)
            {
                $result=$this->get_meals($id_category);
            }
             
            echo json_encode($result);
            
        //}
        }
        
        public function get_meals($id_parent)
        {
            $this->load->model('MealsTree_model');
            $result=$this->MealsTree_model->get_children($id_parent);
            return $result;
        }


        public function get_price_ajax() 
        {        
        //if ($this->input->is_ajax_request())
        //{
            
            $id_meal=$this->input->post('id_meal');
             $result="00.00";
             if ($id_meal)
             {
                 $result=$this->get_price($id_meal);
             }
             
            echo  json_encode($result);
        
        //}
        }

        public function get_price($id)
        {
            $description_field_position=6;
            $price=0;
            $this->load->model('MealsTree_model');
            $result=$this->MealsTree_model->get_children($id,0,true);
            if (count($result)==1)
            {
                $descr=trim($result[0][$description_field_position]);
                if ($descr)
                {
                    $description_array=explode(';', $descr);
                    $price=$description_array[0];
                    //$raw_descr=$description_array[1];

                }
            }
            return $price;
        }
        
    public function register()
	{            
        $this->load->model('MealsTree_model');
        $data['category']=$this->input->post('category');
        $id_meal=$this->input->post('meal');
        $cost=$this->input->post('cost');
        $quantity=$this->input->post('quantity');

        $data['category_options']=$this->MealsTree_model->get_children();
        $data['category_options'][""]='--Choose--';
        ksort($data['category_options']);

        if ($data['category'])
        {
            $data['meals_options']=$this->get_meals($data['category']);
        }
        $data['meals_options'][""]='--Choose--';
        ksort($data['meals_options']);

        
        

        

    
            $data['controller'] = $this->uri->segment(1);
            $data['load_jquerycode']=TRUE;
            
            $this->load->view('orders/register',$data);
	}
        
        
    public function create()
	{

            $this->form_validation->set_error_delimiters('<div class="text-danger">', '</div>');
            $this->form_validation->set_rules('category', 'Category', 'required|greater_than[0]',['required'=>'%s es requerido','greater_than'=>'%s debe ser mayor a cero']);
            $this->form_validation->set_rules('meal', 'Meal', 'required|greater_than[0]',['required'=>'%s es requerido','greater_than'=>'%s debe ser mayor a cero']);
            $this->form_validation->set_rules('cost', 'Cost', 'required|greater_than[0]',['required'=>'%s es requerido','greater_than'=>'%s debe ser mayor a cero']);
            $this->form_validation->set_rules('quantity', 'Quantity', 'required|greater_than[0]',['required'=>'%s es requerido','greater_than'=>'%s debe ser mayor a cero']);
                        
            if ($this->form_validation->run() == FALSE)
            {                                
                $this->register();                
            }
            else
            {

                //exit("ready to save into orders table");
                $id_category    = $this->input->post('category');
                $id_meal = $this->input->post('meal');
                $cost = $this->input->post('cost');
                $quantity = $this->input->post('quantity');
                $description = $this->input->post('description');

                $id_category = $this->input->post('category');
                $id_service = $this->input->post('service');
                $cost = $this->input->post('cost');

                $this->load->model('MealsTree_model');
                $result=$this->MealsTree_model->get_children($id_meal,0,true);
                $meal_key=$result[0][4];
                
                $data=array( 'id_user'=>$this->session->userdata("id_user"), 
                            'id_meal'=>$id_meal,
                            'meal_key'=>$meal_key,
                            'quantity'=>$quantity,
                            'cost'=>$cost);

                $this->model_self->insert($data);
                redirect('dashboard');
                    
            }
        }
        
        
        
}
