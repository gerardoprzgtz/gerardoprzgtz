<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profiles extends MY_Controller {

    
    public $available_methods_ajax=array();
        
        public function __construct() 
        {
            parent::__construct();
            $this->load->helper('form');              
            $this->load->library('form_validation');
            $this->load->model('Orders_model','model_self');
            
            
            $method= strtolower($this->uri->segment(2,'index'));
            
                    $access_ok = $this->verify_permission();
                    if (! $access_ok )
                    {
                        show_error('<a href="' . base_url() . 'welcome">Get Login...!!!</a>',500,"Sorry you have not enough permission..!");
                    }
             
        }
        
        
	public function index()
	{              
            $data['available_controllers'] =$this->available_controllers; 
            $this->load->view('template/top_menu');
            $this->load->view('template/sidebar_menu',$data);
            $this->load->view('profiles/data_list',$data);
            $this->load->view('template/pre_bottom_menu');
            $this->load->view('template/bottom_menu');
	}
          
}
