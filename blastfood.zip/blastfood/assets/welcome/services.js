$(document).ready(function(){

  // jQuery methods go here...

 //$("button").click(function(){
    //$("p").hide(1000);
    
    //$(".animated").fadeOut(5000);
    
    // $("#panel").slideDown("slow");
    
    $(".animated").slideUp(3000).slideDown(1000).fadeOut(2000);
    
    //alert("ok");
    //$(".img_animated").addClass("fadeIn");
   
    
 // });
});